import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Menu, X, Facebook, Youtube, Twitter, Contact } from 'lucide-react'; // Social icons
import logo from '../images/ghurki-logo.png';
import { Link } from 'react-router-dom';

const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const navItems = [
    { path: '/', label: 'Home' },
    { path: '/about', label: 'About Us' },
    { path: '/department', label: 'Department' },
    { path: '/hospital', label: 'Hospital-Amenities' },
    { path: '/gchs', label: 'GCHS' },
    { path: '/contact', label: 'Contact' } 
  ];

  return (
    <div className="w-full">
      {/* 🔴 Top Red Strip */}
      <div className="bg-red-600 w-full h-11 flex justify-end items-center  pr-6 gap-6 text-white text-sm font-medium">
        <NavLink to="/lab-reports" className="hover:underline">Online Lab Reports</NavLink>
        <NavLink to="/donate" className="hover:underline">Donate Now</NavLink>
        <NavLink to="/careers" className="hover:underline">Careers</NavLink>

        {/* Social Media Icons */}
        <div className="flex items-center gap-4 ml-4">
          <a href="https://www.facebook.com/GhurkiTrustTeachingHospital" target="_blank" rel="noopener noreferrer">
            <Facebook size={18} className="hover:text-blue-300" />
          </a>
          <a href="https://www.youtube.com/GhurkiTrustTeachingHospital" target="_blank" rel="noopener noreferrer">
            <Youtube size={18} className="hover:text-red-300" />
          </a>
          <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer">
            <Twitter size={18} className="hover:text-blue-300" />
          </a>
        </div>
      </div>

      {/* ⚪ Main Navbar */}
      <nav className="bg-white  w-full px-4 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between cursor-pointer">
          {/* Logo */}
          <img src={logo} alt="Ghurki Logo" className="h-14 w-auto" />

          {/* Desktop Links */}
          <ul className="hidden md:flex gap-11 text-gray-800 font-medium text-lg">
  {navItems.map((item) => (
    <li key={item.path} className="relative group">
      <NavLink
        to={item.path}
        className={({ isActive }) =>
          isActive ? 'text-red-600 font-semibold' : 'hover:text-red-600 transition'
        }
      >
        {item.label}
      </NavLink>

      {/* 🔽 Dropdown menu for Department */}
      {item.label === 'Department' && (
        <ul className="absolute left-0 top-full mt-2 w-52 bg-white shadow-lg rounded-lg hidden  group-hover:block group-focus-within:block z-50">
          <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer"> <Link to="/NEPHROLOGY">NEPHROLOGY</Link></li>
          <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer"><Link to='OPHTHALMOLOGY'> OPHTHALMOLOGY</Link></li>
          <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer"><Link to='GASTROENTEROLOGY'>GASTROENTEROLOGY</Link></li>
          <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer"><Link to='PlasticSurgery'>Plastic Surgery</Link></li>
          <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer"><Link to='Physiotherapy'>Physiotherapy</Link></li>
          <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer"><Link to='Radiology'>Radiology</Link></li>
        </ul>
      )}

      {/* Underline animation */}
      <div className="w-0 group-hover:w-full h-0.5 bg-red-600 transition-all duration-300"></div>
    </li>
  ))}
</ul>

          {/* Mobile Menu Icon */}
          <button
            className="md:hidden text-gray-700"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

     
      </nav>
    </div>
  );
};

export default Navbar;
